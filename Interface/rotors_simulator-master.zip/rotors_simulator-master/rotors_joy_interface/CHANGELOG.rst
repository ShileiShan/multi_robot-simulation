^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rotors_joy_interface
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.2.3 (2018-12-13)
------------------

2.2.2 (2018-12-12)
------------------

2.2.0 (2018-12-10)
------------------
* Merge pull request `#397 <https://github.com/ethz-asl/rotors_simulator/issues/397>`_ from ethz-asl/v2.1.1
  update to 2.1.1
* Contributors: Mina Kamel

2.1.1 (2017-04-27)
-----------
* update maintainers
* Contributors: fmina

2.1.0 (2017-04-08)
-----------
* Adding interface for Python-uinput, a virtual keyboard joystick
* Adapting the joystick node for use with fixed-wing
* Removing keyboard teleop node
* Adding keyboard interface node
* Contributors: Fadri Furrer, Pavel

2.0.1 (2015-08-10)
------------------

2.0.0 (2015-08-09)
------------------
* Propagate mav_comm changes.
* Contributors: Helen Oleynikova

1.1.6 (2015-06-11)
------------------
* removed wrong install folder

1.1.5 (2015-06-09)
------------------
* added install targets

1.1.4 (2015-05-28)
------------------

1.1.3 (2015-05-28)
------------------

1.1.2 (2015-05-27)
------------------

1.1.1 (2015-04-24)
------------------

1.1.0 (2015-04-24)
------------------
* initial Ubuntu package release
