#!/usr/bin/env python

import rospy
from allocation_within_area.msg import allocationResult, one_sequence

def result_publisher():
	rospy.init_node("result_publisher", anonymous = True)
	result_info_pub = rospy.Publisher("/allocation_result", allocationResult, queue_size = 10)

	result_msg = list()
	one_msg = one_sequence()
	one_msg.id = 1
	one_msg.targets = [1,0]
	result_msg.append(one_msg)
	
	one_msg = one_sequence()
	one_msg.id = 2
	one_msg.targets = [3,2]
	result_msg.append(one_msg)
	
	n = 25000
	while(n>0):
		result_info_pub.publish(result_msg)
		n -= 1


if __name__ == '__main__':
	try:
		result_publisher()
	except rospy.ROSInterruptException:
		pass
